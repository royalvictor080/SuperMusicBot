API_ID = 22946064
API_HASH = "ddabd88a190cacfdb968aefea81d9579"
BOT_TOKEN = "7704675640:AAGOLDY2siBDWwBSVj7TL3XPSa69sG2c_nE"
MONGO_URI = "mongodb+srv://bigfankftrs:bigfankftrs@cluster0.gkxlmpt.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0"
FFMPEG_PATH = r"C:\Users\rstra\ffmpeg\bin\ffmpeg.exe"
